package com.example.notifyme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText edtTxtUser,edtTxtPassword;
    private Button button;
    private TextView textView;
    private String Username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtTxtUser = findViewById(R.id.edtTxtUser);
        edtTxtPassword = findViewById(R.id.edtTxtPassword);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendData();
            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(i);
            }
        });
    }
    public void sendData(){
        Username = edtTxtUser.getText().toString().trim();
        Intent intent=new Intent(MainActivity.this,PageActivity.class);
        intent.putExtra(PageActivity.Username,Username);
        startActivity(intent);
    }
}