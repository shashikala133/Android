package com.example.notifyme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
    private EditText editTextPersonName,editTextPersonName2,editTextEmailAddress,editTextPassword,editTextPassword2;
    private Button button2;
    private String Username;
    //FirebaseDatabase rootNode;
    //DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        editTextPersonName = findViewById(R.id.editTextPersonName);
        editTextPersonName2 = findViewById(R.id.editTextPersonName2);
        editTextEmailAddress = findViewById(R.id.editTextEmailAddress);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextPassword2 = findViewById(R.id.editTextPassword2);
        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendData();
            }
        });
    }
    public void sendData(){
        Username = editTextPersonName2.getText().toString().trim();
        Intent intent=new Intent(RegisterActivity.this,PageActivity.class);
        intent.putExtra(PageActivity.Username,Username);
        startActivity(intent);
    }
    }
