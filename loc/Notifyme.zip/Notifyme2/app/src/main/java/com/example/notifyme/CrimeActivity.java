package com.example.notifyme;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class CrimeActivity extends AppCompatActivity {
    ListView l;
    EditText n;
    EditText m;
    Button b;
    ArrayList<String> arr;  //length of array cannot be updated
    ArrayAdapter<String> adp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crime);
        l = findViewById(R.id.lv);
        n = findViewById(R.id.name);
        m = findViewById (R.id.number);
        b = findViewById(R.id.add);
        arr = new ArrayList<String>();
        //arr.add("ABC");
        //arr.add("DEF");
        //arr.add("GHI");
        adp = new ArrayAdapter<String>(CrimeActivity.this,android.R.layout.simple_list_item_1,arr);
        l.setAdapter(adp);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = n.getText().toString();
                String num = PhoneNumberUtils.formatNumber (m.getText ().toString ());
                arr.add(name);
                adp.notifyDataSetChanged();
                arr.add(String.valueOf (num));
                adp.notifyDataSetChanged ();

            }
        });
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(CrimeActivity.this, arr.get(i), Toast.LENGTH_SHORT).show();
            }
        });
        l.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder adb = new AlertDialog.Builder(CrimeActivity.this);
                adb.setTitle("ALERT");
                adb.setCancelable(false);
                adb.setMessage("Do you want to delete the item?");
                adb.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i1) {
                        arr.remove(i);
                        adp.notifyDataSetChanged();
                    }
                });
                adb.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                AlertDialog a = adb.create();
                a.show();
                return true;
            }
        });
    }




}
