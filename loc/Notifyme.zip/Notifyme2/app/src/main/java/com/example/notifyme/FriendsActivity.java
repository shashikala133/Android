package com.example.notifyme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class FriendsActivity extends AppCompatActivity {
    ListView l;
    EditText n;
    EditText m;
    Button b;
    ArrayList<String> arr;  //length of array cannot be updated
    ArrayAdapter<String> adp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_friends);
        l = findViewById (R.id.lv);
        n = findViewById (R.id.name);
        m = findViewById (R.id.number);
        b = findViewById (R.id.add);
        arr = new ArrayList<String> ();

        adp = new ArrayAdapter<String> (FriendsActivity.this, android.R.layout.simple_list_item_1, arr);
        l.setAdapter (adp);

        b.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                String name = n.getText ().toString ();
                String num = PhoneNumberUtils.formatNumber (m.getText ().toString ());
                arr.add (name);
                adp.notifyDataSetChanged ();
                arr.add (String.valueOf (num));
                adp.notifyDataSetChanged ();

            }
        });
        l.setOnItemClickListener (new AdapterView.OnItemClickListener () {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText (FriendsActivity.this, arr.get (i), Toast.LENGTH_SHORT).show ();
            }
        });
        l.setOnItemLongClickListener (new AdapterView.OnItemLongClickListener () {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final AlertDialog.Builder alert = new AlertDialog.Builder (FriendsActivity.this);
                View mView = getLayoutInflater ().inflate (R.layout.custom_dialog, null);
                Button btn_cancel = (Button) mView.findViewById (R.id.btn_cancel);
                Button btn_send = (Button) mView.findViewById (R.id.btn_send);
                alert.setView (mView);
                final AlertDialog alertDialog = alert.create ();

                alertDialog.setCanceledOnTouchOutside (false);

                btn_cancel.setOnClickListener (new View.OnClickListener () {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss ();
                    }
                });

                btn_send.setOnClickListener (new View.OnClickListener () {
                    @Override
                    public void onClick(View view) {
                        long num1 = Long.parseLong (m.getText ().toString ());
                        if (ContextCompat.checkSelfPermission (FriendsActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            SmsManager smsManager = SmsManager.getDefault ();
                            smsManager.sendTextMessage (String.valueOf (num1), null, "I'm in danger", null, null);
                            Toast.makeText (getApplicationContext (), "SMS sent successfully", Toast.LENGTH_LONG).show ();

                        } else {
                            ActivityCompat.requestPermissions (FriendsActivity.this, new String[]{Manifest.permission.SEND_SMS}, 100);
                        }

                    }

                /*    private void sendMessage() {
                      String num1 = number.getText ().toString ();
                       //if(!num1.equals ("")) {
                            SmsManager smsManager = SmsManager.getDefault ();
                            smsManager.sendTextMessage ("7349156812", null, "hiiii", null, null);
                            Toast.makeText (getApplicationContext (), "SMS sent successfully", Toast.LENGTH_LONG).show ();
                       // }else {
                         //   Toast.makeText (getApplicationContext (), "Enter value", Toast.LENGTH_LONG).show ();
                        //}

                    }*/
                });
                alertDialog.show ();
                return true;
            }
        });
    }
}